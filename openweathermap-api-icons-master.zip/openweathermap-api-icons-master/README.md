# openweathermap-api-icons
**How to include Icons in your Application (OpenWeather Map API)**

 Icons taken from this project: *https://github.com/CodeExplainedRepo/Weather-App-JavaScript*
 
 Include the icon file in your program to use this.
 
 Step-by-step instructions at: *https://stackoverflow.com/a/62369654/10552501*
 
